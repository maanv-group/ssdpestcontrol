<meta charset="utf-8">
<meta name="description" content="Highly effective pest control services offered by us in Mumbai, Thane, Pune, Goa. SSD Pest control is best professional pest Control Company in mumbai , providing safe & secure pest solutions.">
<meta name="keywords" content="Pest Control Services mumbai, Pest Control Company mumbai, Pest Control in Mumbai, Pest Control in borivali, Pest Control Services in Thane, Pest Control Services in Pune, Pest Control Services in Goa, Best Pest Control Company" />

<meta name="robots" content="index, follow" />
<meta name="googlebot" content="index, follow" />
<meta name="classification" content="Pest control Service" />
<meta name="resource-type" content="Pest control Service " />
<meta name="revisit-after" content="5 days" />
<meta name="rating" content="General" />
<meta name="copyright" content="2023" />
<meta name="Voluntary Content Rating" content="general" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta name="language" content="English" />
<meta name="author" content="ssdpestcontrolr.com">

<!-- Stylesheets -->
<link href="<?= base_url()?>assets/css/bootstrap.css" rel="stylesheet">
<link href="<?= base_url()?>assets/css/style.css" rel="stylesheet">
<!-- Responsive File -->
<link href="<?= base_url()?>assets/css/responsive.css" rel="stylesheet">
<!-- Color File -->
<link href="<?= base_url()?>assets/css/color.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&amp;family=Poppins:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">


<link rel="shortcut icon" href="<?= base_url()?>assets/images/weblogo.png" type="image/x-icon">
<link rel="icon" href="<?= base_url()?>assets/images/weblogo.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<meta name=""google-site-verification=-uz8yVyA41XIkOLCKmQe-2o0taH1b3zaX-jZqfVrhdI"" />
