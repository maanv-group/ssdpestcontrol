<!--Main Footer-->
<footer class="main-footer">
	<div class="upper-box">
		<div class="auto-container">
			<div class="row">
				<div class="col-lg-3 col-md-7">
					<div class="widget about-widget">
						<h4 class="widget_title">About </h4>
						<div class="text">Established in the year 2010, we, SSD Pest Control Company, are engaged in providing effective services for pest control in Mumbai.
							We have specialized in offering residential, commercial,
							marina and corporate pest control services.</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-6">
					<div class="widget links-widget">
						<h4 class="widget_title">Usefull Link</h4>
						<div class="widget-content">
							<ul class="list">
								<li><a href="<?= base_url() ?>">Home </a></li>
								<li><a href="<?= base_url() ?>about-us">About Company</a></li>
								<li><a href="<?= base_url() ?>">Services</a></li>
								<li><a href="<?= base_url() ?>clients">clients</a></li>
								<li><a href="<?= base_url() ?>gallery">Gallery </a></li>
								<li><a href="<?= base_url() ?>">Our Blog </a></li>
								<li><a href="<?= base_url() ?>contact-us">Contact Us</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="widget links-widget">
						<h4 class="widget_title">Our Service</h4>
						<div class="widget-content">
							<ul class="list">
								<li><a href="<?= base_url("cockroach-pest-control-services") ?>">Cockroach Pest Control</a></li>
								<li class="active"><a href="<?= base_url("termites-pest-control-services") ?>">Termites Control Service</a></li>
								<li><a href="<?= base_url("bed-bug-pest-control-service") ?>">Bed Bug Control Service</a></li>
								<li><a href="<?= base_url("mosquito-pest-control-services") ?>">MOSQUITO CONTROL Service</a></li>
								<li><a href="<?= base_url("rat-guard-service") ?>">Rat Guard Service </a></li>
								<li><a href="<?= base_url("bird-netting-service") ?>">BIRD NETING Service</a></li>
								<li><a href="<?= base_url("fly-pest-control") ?>">Fly Control Service</a></li>
								<li><a href="<?= base_url("rodent-pest-control") ?>">Rodent Control Service</a></li>
								<li><a href="<?= base_url("spider-pest-control") ?>">Spider Pest Control</a></li>
								<li><a href="<?= base_url("residential-pest-control-service") ?>">Residential Pest Control</a></li>
								<li><a href="<?= base_url("commercial-pest-control-service") ?>">Commercial Pest Control</a></li>
								<!-- <li><a href="<?= base_url() ?>PRE-CONSTRUCTION-ANTI-TERMITE-TREATMENT">Pre Construction Anti Termite Treatment</a></li> -->
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-3 offset-lg-1 col-md-6">
					<div class="widget contact-widget">
						<h4 class="widget_title">Contact</h4>
						<ul>
							<li>Shop No.1, Pravin Nagar, Behind V.M.V College, Amravati, Maharashtra, 444604</li>
							<li><a href="mailto:info@ssdpestcontrol.com">info@ssdpestcontrol.com</a></li>
							<li><a href="tel:+919594232394">+91 9594232394</a></li>
							<li><a href="tel:+919820524866">+91 9820524866</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
<!--End Main Footer-->

<div class="footer-bottom">
	<div class="auto-container">
		<div class="content">
			<li><a href="<?= base_url() ?>">© 2023 SSD Pest Control, All Right Reserved. </a></li>
			<ul class="social-icon">
				<li><a href="https://www.facebook.com/ssdpestcontrol"><i class="fab fa-facebook-f"></i></a></li>
				<li><a href="https://www.instagram.com/ssd.pestcontrol/"><i class="fab fa-instagram"></i></a></li>
				<li><a href="https://twitter.com/ssdpestcontrol_"><i class="fab fa-twitter"></i></a></li>
				<li><a href="https://www.youtube.com/@SSDPESTCONTROLSERVICE"><i class="fab fa-youtube"></i></a></li>
			</ul>
			<div class="footer-menu">
				<ul>
					<li><a href="<?= base_url() ?>">Terms of Service </a></li>
					<li><a href="<?= base_url() ?>">Privacy Policy</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
