<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title> About - SSD Pest Control Service In Mumbai | Top Pest Control Near Me | Mumbai Pest Control</title>
<meta name="description" content="Highly effective pest control services offered by us in Mumbai, Thane, Pune, Goa. SSD Pest control is best professional pest Control Company, providing safe & secure pest solutions.">
<meta name="keywords" content="Pest Control Services, Pest Control Company, Pest Control in Mumbai, Pest Control in borivali, Pest Control Services in Thane, Pest Control Services in Pune, Pest Control Services in Goa, Best Pest Control Company" />

<!-- Stylesheets -->
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<!-- Responsive File -->
<link href="assets/css/responsive.css" rel="stylesheet">
<!-- Color File -->
<link href="assets/css/color.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&amp;family=Poppins:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">

<link rel="shortcut icon" href="assets/images/weblogo.png" type="image/x-icon">
<link rel="icon" href="assets/images/weblogo.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->


    <!-- Main Header -->
    <header class="main-header">

        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container">
                <div class="inner-container">
                    <div class="left-column">
                        <div class="location"><i class="flaticon-placeholder"></i> Welcome To SSD pest control</div>                        
                    </div>
                    <div class="right-column">
                        <div class="search-btn"><button type="button" class="theme-btn search-toggler"><span class="flaticon-search-1
                            "></span></button></div>
                        <ul class="contact-info">
                            <li><a href="tel:2107636992"><i class="flaticon-call"></i>+91 9594232394</a></li>
                            <li><a href="mailto:info@ssdpestcontrol.com"><i class="flaticon-email-1"></i>info@ssdpestcontrol.com </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Header Upper -->
        <div class="header-upper">
            <div class="auto-container">
                <div class="inner-container">
                    <!--Logo-->
                    <div class="logo-box">
                        <div class="logo"><a href="index.html"><img src="assets/images/weblogo.png" alt=""></a></div>
                    </div>
                    <!--Nav Box-->
                    <div class="nav-outer">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler"><img src="assets/images/icons/icon-bar.png" alt=""></div>

                        <!-- Main Menu -->
                            <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation">
                                    <li class="dropdown"><a href="index.html">Home</a>
                                    </li>
									                                    <li class="dropdown"><a href="about.html">About Us</a>
                                        <ul>
                                            <li><a href="about.html">About SSD Pest Control</a></li>
                                            <li class="active"><a href="">Our Business</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="">Our Services</a>
                                        <ul>
                                            <li><a href="cockroach-pest-control.html">Cockroach Pest Control</a></li>
                                            <li class="active"><a href="Termites-control-mumbai.html">Termites Control Service</a></li>
                                            <li><a href="mosquito-control-services-mumbai.html">MOSQUITO CONTROL Service</a></li>
                                            <li><a href="Rodents-control-services-mumbai.html">Rodent Control Service</a></li>
                                            <li><a href="Fly-control-services-mumbai.html">Fly Control Service</a></li>
                                            <li><a href="Bird-Netting-Services-mumbai.html">BIRD NETING Service</a></li>
                                            <li><a href="Bed-Bug-control-services-Mumbai.html">Bed Bug Control Service</a></li>
											  <li><a href="Rat-Guard-Services-mumbai.html">Rat Guard Service </a></li>
											    <li><a href="commercial-pest-control-service-mumbai.html">Commercial Pest Control</a></li>
												 <li><a href="Residential-pest-control-service-mumbai.html">Residential Pest Control</a></li>
												 <li><a href="pre-construction-pest-control-amravati.html">Pre Construction Anti Termite Treatment</a></li>
                                        </ul>
                                    </li>
  
									 <li><a href="gallery.html">Gallery</a></li>
									  <li><a href="clinets.html">Client</a></li>
                                    <li><a href="contact.html">Contact</a></li>
								 <li class="dropdown"><a href="Pest-Control-mumbai.html">Our Location</a>
                                        <ul>
                                            <li><a href="Pest-Control-mumbai.html"> Mumbai</a></li>
                                            <li><a href="Pest-Control-goregaon.html">Goregaon</a></li>
                                            <li><a href="Pest-Control-Amravati.html">Amravati</a></li>
                                            <li><a href="Pest-Control-Partwada.html">Partwada</a></li>
                                            <li class="active"><a href="thane-pest-control.html">Thane</a></li>
                                            <li><a href="Pest-Control-Navi-Mumbai.html">Navi Mumbai</a></li>
											<li><a href="Pest-Control-Pune.html">Pune</a></li>
											<li><a href="Pest-Control-Palgher.html">Palgher</a></li>
											<li><a href="Pest-Control-Nashik.html">Nashik</a></li>
											<li><a href="Pest-Control-Ahmedabad.html">Ahmedabad</a></li>
											<li><a href="Pest-Control-Service-Shegaon.html">Shegaon</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="link-btn"><a href="https://api.whatsapp.com/send/?phone=919594232394&text&type=phone_number&app_absent=0" class="theme-btn btn-style-one"><span>Appointment</span></a></div>
					
                </div>
            </div>
        </div>
        <!--End Header Upper-->

        <!-- Sticky Header  -->
        <div class="sticky-header">
            <div class="header-upper">
                <div class="auto-container">
                    <div class="inner-container">
                        <!--Logo-->
                        <div class="logo-box">
                            <div class="logo"><a href="index.html"><img src="assets/images/weblogo.png" alt=""></a></div>
                        </div>
                        <!--Nav Box-->
                        <div class="nav-outer">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler"><img src="assets/images/icons/icon-bar-2.png" alt=""></div>
    
                            <!-- Main Menu -->
                            <nav class="main-menu navbar-expand-md navbar-light">
                            </nav>
                        </div>
                        <div class="link-btn"><a href="contact.html" class="theme-btn btn-style-one"><span>Appointment</span></a></div>
                    </div>
                </div>
            </div>
        </div><!-- End Sticky Menu -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><span class="icon flaticon-remove"></span></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.html"><img src="assets/images/weblogo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
				<!--Social Links-->
				<div class="social-links">
					<ul class="clearfix">
						<li><a href="#"><span class="fab fa-twitter"></span></a></li>
						<li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
						<li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
						<li><a href="#"><span class="fab fa-instagram"></span></a></li>
						<li><a href="#"><span class="fab fa-youtube"></span></a></li>
					</ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->

        <div class="nav-overlay">
            <div class="cursor"></div>
            <div class="cursor-follower"></div>
        </div>
    </header>
    <!-- End Main Header -->

    <!--Search Popup-->
    <div id="search-popup" class="search-popup">
        <div class="close-search theme-btn"><span class="flaticon-remove"></span></div>
        <div class="popup-inner">
            <div class="overlay-layer"></div>
            <div class="search-form">
                <form method="post" action="http://html.tonatheme.com/2020/Pestico/index.html">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                            <input type="submit" value="Search Now!" class="theme-btn">
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Page Title -->
    <section class="page-title" style="background-image: url(assets/images/background/bg-3.jpg);">
	</br>
	</br>
		</br>
	</br>
		</br>
	</br>
    <div class="row">
        <div class="btn-group btn-breadcrumb">
            <a href="#" class="btn btn-info">Home</a>
			<a href="#" class="btn btn-info">About Us</a>

        </div>
	</div>
    </section>
<ul class="breadcrumb">
<h5 class="table text-center" > FLAT 15% OFF!! ON ALL PEST CONTROL ANNUAL CONTRACTS (Toll Free) <a href="tel:+919820524866">+91 9987872255 </a> </h5>
</ul>

    <!-- About Section -->
    <section class="about-us-section">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="image-wrapper wow fadeInDown" data-wow-duration="1500ms">
                        <span class="shape-one"><img src="assets/images/shape/shape-2.png" alt=""></span>
                        <span class="shape-two"><img src="assets/images/shape/shape-3.png" alt=""></span>
                        <div class="image">
                            <img src="assets/images/resource/ssdaboutus.jpeg" alt="">
                        </div>
                        <div class="years-of-experience" data-parallax='{"y": 50}'>
                            <svg  xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                width="349px" height="359px">
                                <defs>
                                <filter filterUnits="userSpaceOnUse" id="Filter_0" x="0px" y="0px" width="349px" height="359px"  >
                                    <feOffset in="SourceAlpha" dx="-28.284" dy="28.284" />
                                    <feGaussianBlur result="blurOut" stdDeviation="7.746" />
                                    <feFlood flood-color="rgb(37, 59, 112)" result="floodOut" />
                                    <feComposite operator="atop" in="floodOut" in2="blurOut" />
                                    <feComponentTransfer><feFuncA type="linear" slope="0.03"/></feComponentTransfer>
                                    <feMerge>
                                    <feMergeNode/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                                </filter>

                                </defs>
                                <g filter="url(#Filter_0)">
                                <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                                d="M287.000,30.999 L117.000,30.999 C100.431,30.999 87.000,44.429 87.000,60.998 L87.000,270.999 L287.000,240.999 C303.464,238.598 317.000,227.567 317.000,210.999 L317.000,60.998 C317.000,44.429 303.569,30.999 287.000,30.999 Z"/>
                                </g>
                            </svg>
                            <h4>15 +</h4>
                            <div class="text">Years of Experiences</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="content-block wow fadeInUp" data-wow-duration="1500ms">
                        <div class="sec-title mb-20">
                            <div class="sub-title">About </div>
                            <h2>SSD Pest Contol.</h2>
                        </div>
                        <div class="text">.SSD Pest Control is the leading pest control service provider in mumbai. 
						A SSD Pest Control Initial brand, SSD Pest Control was formed in 2010 through a joint venture (JV) 
						between Pest Control mumbai, the number one pest control company in mumbai, 
                          SSD Pest Control aims to set new standards for customer 
						service having operations across 150 locations in mumbai. SSD Pest Control also focuses on developing 
						industry-leading service operations through the sharing of best practices, new innovations and the use of digital technologies</div>
                        <ul class="list">
                            <li>Affordable Service.</li>
                            <li>On-time, Any Time.</li>
                            <li>Intensively Trained Team.</li>
                        </ul>
                    </div>
                </div>
            </div>
			</br>
			
			 <div class="text">Established in the year 2010, we, SSD Pest Control Company, 
			 are engaged in providing effective services for pest control in Mumbai. We 
			 have specialized in offering residential, commercial, marina and corporate pest control services. 
			 SSD Pest Control Service In Mumbai is looking to set new global standards in providing all sort of 
			 facility management services at affordable cost by developing innovative pro-environmental superior technologies.</div>
			 <div class="text">SSD Pest Control Services Private Limited is an ISO Certified government approved organisation providing 
			 the best pest control service in Mumbai, officially formed Team is SSD Pest Control Services.Our elimination activities 
			 are strictly enforced under the guidelines of the pest control industry, obliged to follow the government regulations. 
			 SSD Pest Control Services constantly strives to improve the industry standards of pest controlling with the help of 
			 constant research and development. Our specially trained professionals, capable of Pest Risk Assessment and proactive 
			 Measures for the specific problems, are expertise in handling different resources and applicators as well. We are consistent 
			 in providing the promised quality service to our trusted customers; the real pillars of our great success..</div>
			 <h2> Our Mission</h2>
			 <P> To protect, preserve and nurture the health, safety and well-being of our clients, their families and neighbors by providing the most comprehensive and high quality pest control solutions that exceed expectations</P>
			 </br>
			 
			 <h2> Our Vision </h2>
			 <p> To gain excellence through our state-of-the-art professional pest control services in accordance with the highest industry standards</p>
        </div>
        
    </section>



    <!-- Whychoose us section two -->
    <section class="whychoose-us-section-two">
        <div class="sec-bg">
            <div class="left-side">
                <svg xmlns="http://www.w3.org/2000/svg" width="960" height="788"><path fill-rule="evenodd" fill="#111B31" d="M0-.001h960V788l-840-70c-27.339-2.48-46.419-22.524-50-50.001L0-.001z"/></svg>
            </div>
            <div class="right-side" style="background-image: url(assets/images/background/bg-2.jpg);"></div>
        </div>
        <span class="shape-one"><img src="assets/images/shape/shape-4.png" alt=""></span>
        <span class="shape-two"><img src="assets/images/shape/shape-5.png" alt=""></span>        
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sec-title light mb-20">
                        <div class="sub-title">Why Choose us</div>
                        <h2>SSD PEST <br> CONTROL SERVICES?</h2>                        
                    </div>
                    <div class="text light mb-40">We have our strong presence around the Mumbai and are widely appreciated for <br> our effective Pest Control Services In Mumbai, which are in line <br> with the customers’ requirements..</div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="icon-box wow fadeInUp" data-wow-duration="1500ms">
                                <div class="icon"><span class="flaticon-settings"></span></div>
                                <div class="content">
                                    <h4>24/7 Availability</h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="icon-box wow fadeInUp" data-wow-duration="1500ms">
                                <div class="icon"><span class="flaticon-pesticide"></span></div>
                                <div class="content">
                                    <h4>Perfection and Quality</h4>
                                </div>
                            </div>
                        </div>
						                        <div class="col-lg-4">
                            <div class="icon-box wow fadeInUp" data-wow-duration="1500ms">
                                <div class="icon"><span class="flaticon-pesticide"></span></div>
                                <div class="content">
                                    <h4>Client Centric Orientation</h4>
                                </div>
                            </div>
                        </div>
												                        <div class="col-lg-4">
                            <div class="icon-box wow fadeInUp" data-wow-duration="1500ms">
                                <div class="icon"><span class="flaticon-pesticide"></span></div>
                                <div class="content">
                                    <h4>Economic prices</h4>
                                </div>
                            </div>
                        </div>
																		                        <div class="col-lg-4">
                            <div class="icon-box wow fadeInUp" data-wow-duration="1500ms">
                                <div class="icon"><span class="flaticon-pesticide"></span></div>
                                <div class="content">
                                    <h4>Fast response time to emergency</h4>
                                </div>
                            </div>
                        </div>
																		                        <div class="col-lg-4">
                            <div class="icon-box wow fadeInUp" data-wow-duration="1500ms">
                                <div class="icon"><span class="flaticon-pesticide"></span></div>
                                <div class="content">
                                    <h4>Well executed services</h4>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    
    </br>
    </br>
    
    
    	    <section class="faq-section">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="text-block">
                        <h4>ISO certificate :</h4>
					   <div class="info-wrapper">
                        <div class="info-block">
                            					               <a href="">
          <img src="assets/images/bayer.png" alt="bayer"/>
        </a>
                            <div class="text mb-2">SSD Pest Control Service, We registered in iso certificate  in 2010. We are channel partners of iso certificate 2010.</div>

                            </br>
                        </div>

                    </div>
					
					</div>
					
                </div>

                <div class="col-lg-6">
                    <div class="text-block">
                        <h4>PCAI  :</h4>
					   <div class="info-wrapper">
					               <a href="">
          <img src="assets/images/pcai.png" alt="bayer"/>
        </a>
                        <div class="info-block">
                            <div class="text mb-2">SSD Pest Control Services is the member of Pest Control Association of India.</div>

                            </br>
                        </div>

                    </div>
					
					</div>
					
                </div>
                                <div class="col-lg-6">
                    <div class="text-block">
                        <h4>MCGM : </h4>
					   <div class="info-wrapper">
					               <a href="">
          <img src="assets/images/mcgm.png" alt="bayer"/>
        </a>
                        <div class="info-block">
                            <div class="text mb-2">SSD Pest Control Service, We have attended training sessions of Municipal Corporation of Greater Mumbai(MCGM).</div>

                            </br>
                        </div>

                    </div>
					
					</div>
					
                </div>
                                <div class="col-lg-6">
                    <div class="text-block">
                        <h4>Intellectual Property India :</h4>
					   <div class="info-wrapper">
					               <a href="">
          <img src="assets/images/pmpwam.png" alt="bayer"/>
        </a>
                        <div class="info-block">
                            <div class="text mb-2">SSD Pest Control Service, We registered in Intellectual Property India in 2020</div>

                            </br>
                        </div>

                    </div>
					
					</div>
					
                </div>
                
                
                
                
            </div>
        </div>
    </section>
    
	


    <!--Main Footer-->
    <footer class="main-footer">
        <div class="upper-box">
            <div class="auto-container">
                <div class="row">
                    <div class="col-lg-3 col-md-7">
                        <div class="widget about-widget">
                            <h4 class="widget_title">About </h4>
                            <div class="text">Established in the year 2010, we, SSD Pest Control Company, are engaged in providing effective services for pest control in Mumbai. 
							We have specialized in offering residential, commercial, 
							marina and corporate pest control services.</div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6">
                        <div class="widget links-widget">
                            <h4 class="widget_title">Usefull Link</h4>
                            <div class="widget-content">
                                <ul class="list">
                                    <li><a href="index.html">Home </a></li>
                                    <li><a href="about.html">About Company</a></li>
									<li><a href="#">Services</a></li>
                                    <li><a href="clinets.html">cleints</a></li>
									<li><a href="gallery.html">Gallery </a></li>
                                    <li><a href="#">Our Blog </a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="widget links-widget">
                            <h4 class="widget_title">Our Service</h4>
                            <div class="widget-content">
                                <ul class="list">
                                    <li><a href="cockroach-control-services-mumbai.html">Cockroach Pest Control </a></li>
                                    <li><a href="mosquito-control-services-mumbai.html">Mosquito Pest Control </a></li>
                                    <li><a href="Termites-control-mumbai.html">Termites Pest Control</a></li>
                                    <li><a href="Rodents-control-services-mumbai.html">Rodents Pest Control </a></li>
                                    <li><a href="Spiders-control-services-Mumbai.html">Spiders Pest Control </a></li>
									<li><a href="Bed-Bug-control-services-Mumbai.html">Bed Bug Pest Control </a></li>
									<li><a href="commercial-pest-control-service-mumbai.html">Commercial Pest Control </a></li>
									<li><a href="Residential-pest-control-service-mumbai.html">Residential Pest Control </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 offset-lg-1 col-md-6">
                        <div class="widget contact-widget">
                            <h4 class="widget_title">Contact</h4>
                            <ul>
                                <li>Shop No.1, Pravin Nagar,  Behind V.M.V College, Amravati, Maharashtra, 444604</li>
                                <li><a href="mailto:info@ssdpestcontrol.com">info@ssdpestcontrol.com</a></li>
                                                               <li><a href="tel:+919594232394">+91 9594232394</a></li>
								<li><a href="tel:+919820524866">+91 9820524866</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 
        </div>               
    </footer>
    <!--End Main Footer-->

    <div class="footer-bottom">
        <div class="auto-container">
            <div class="content">
                        <li><a href="#">© 2023 SSD Pest Control, All Right Reserved. </a></li>
                 <ul class="social-icon">
                    <li><a href="https://www.facebook.com/ssdpestcontrol"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="https://www.instagram.com/ssd.pestcontrol/"><i class="fab fa-instagram"></i></a></li>
				 <li><a href="https://twitter.com/ssdpestcontrol_"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.youtube.com/@SSDPESTCONTROLSERVICE"><i class="fab fa-youtube"></i></a></li>
                </ul>
                <div class="footer-menu">
                    <ul>
                        <li><a href="#">Terms of Service </a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>            
        </div>
    </div>
	
</div>

    <div class="sliding_form slide_out">
        <a href="#" id="form_trigger">Enquiry Form</a>
        <div class="sliding_form_inner">
            <form class="bt-formtheme bt-formcontactus" method="post" id="query_form_enquiry" novalidate="novalidate">
               <div class="messages1"></div>
         <div class="form-group">
       
         <input type="text" name="name_enq" data-error="Name field is required!" class="form-control" placeholder="Name" aria-describedby="basic-addon1" required>
      </div>

      <div class="form-group">
      
            <input type="tel" required="" aria-describedby="basic-addon1" class="form-control" placeholder="Phone Number" data-error="Phone field is required!" name="contact_enq" id="" aria-required="true">
      </div>

      <div class="form-group">
       
        <input type="email" name="email_enq" data-error="Email field is required!" class="form-control" placeholder="Email Id" aria-describedby="basic-addon1" required>
      </div>

      <div class="form-group">
       
         <input type="text" name="city" data-error="City field is required!" class="form-control" placeholder="City" aria-describedby="basic-addon1" required>
      </div>
     
         <div class="form-group kich">
             <p style="color:#c8283e; font-weight: 600;"> *Is this enquiry for your home or business?</p>
            <span class="bt-select">
                <select name="service-type">
                <option value="*">select</option>
                 <option value="Home">Home</option>
                 <option value="Business">Business</option>
                     </select>
              </span>
      </div>
      
      <div class="form-group kich">
            <span class="bt-select">
                <select name="service">
                <option value="*">Type of service</option>
                 <option value="Termites Control">Cockroaches Pest Control</option>
                 <option value="Spiders Control">Termites Control Service</option>
                 <option value="Cockroach Control">Bed Bug Control Service</option>
                  <option value="Rodents Control"> Rodents Control Service</option>
                   <option value="Rodents Control"> Fly Control Service</option>
                   <option value="Cockroach Control"> BIRD NETING Service</option>
                   <option value="Rodents Control">MOSQUITO CONTROL Service</option>
                   <option value="Cockroach Control">Commercial Pest Control</option>
                   <option value="Cockroach Control">Residential Pest Control</option>
                     </select>
              </span>
      </div>

          <div class="clearfix"></div>
      <div id="success"></div>

      <button class="bt-btn bt-btnblack theme-btn btn-style-one nimm" value="submit" type="submit"><span>Submit now</span></button>
        </form>
        </div>
    </div>

<!--End pagewrapper-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send/?phone=919594232394&text&type=phone_number&app_absent=0" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="flaticon-right-arrow-4"></span></div>

<script src="assets/js/jquery.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/js/jquery.fancybox.js"></script>
<script src="assets/js/isotope.js"></script>
<script src="assets/js/owl.js"></script>
<script src="assets/js/appear.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/lazyload.js"></script>
<script src="assets/js/scrollbar.js"></script>
<script src="assets/js/TweenMax.min.js"></script>
<script src="assets/js/swiper.min.js"></script>
<script src="assets/js/jquery.polyglot.language.switcher.js"></script>
<script src="assets/js/jquery.ajaxchimp.min.js"></script>
<script src="assets/js/parallax-scroll.js"></script>

<script src="assets/js/script.js"></script>

<!-- <script>
  $("#fixed-form-container .body").hide();
$("#fixed-form-container .button").click(function () {
        $(this).next("#fixed-form-container div").slideToggle(400);
        $(this).toggleClass("expanded");
    });
</script>  --> 



<script>
    $(document).ready(function() {

    var formWidth = $('.sliding_form').width();
    $('.sliding_form').css('right', '-' + formWidth + 'px');
    $("#form_trigger").on('click', function() {

        if ($('.sliding_form').hasClass('slide_out')) {
            $('.sliding_form').removeClass('slide_out').addClass('slide_in')
            $(".sliding_form").animate({ right: 0 + 'px' });
        } else {
            $('.sliding_form').removeClass('slide_in').addClass('slide_out')
            $('.sliding_form').animate({ right: '-' + formWidth + 'px' });
        }

    });
});
</script>





    <!-- Read only script contact form script  -->
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.js"></script>

<!-- contact form validation and captcha validation  -->

<script type="text/javascript">
      $("#query_form_enquiry").validate({
                rules: {
                    name_enq: {
                        required: true
                    },
                    contact_enq: {
                        required: true
                    },
                    email_enq: {
                        required: true
                    },
                    city: {
                        required: true
                    },
                   
                },
                messages: {
                    name_enq: {
                        required: "Name field is required"
                    },
                    contact_enq: {
                        required: "Contact field is required"
                    },
                    email_enq: {
                        required: "Email field is required"
                    },
                    city: {
                        required: "City field is required"
                    },
                    
                },
                submitHandler: function(form) {                 
                var url = "contactmailHome.php";
                
            // POST values in the background the the script URL
                    $.ajax({
                        type: "POST",
                        url: url,
                        data: $('#query_form_enquiry').serialize(),
                        success: function (data)
                        {
                              $('#query_form_enquiry')[0].reset();
                              grecaptcha.reset();

                              $('#query_form_enquiry').find('.messages1').html(data);
                         
                        }
                    });
                    // form.submit();
              },    
            });

</script>


<!-- contact form validation and captcha validation  -->


</body>


</html>
