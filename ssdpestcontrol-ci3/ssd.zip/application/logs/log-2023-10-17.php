<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-10-17 19:08:13 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:08:13 --> No URI present. Default controller set.
DEBUG - 2023-10-17 19:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:08:13 --> Total execution time: 0.1331
DEBUG - 2023-10-17 19:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:08:59 --> No URI present. Default controller set.
DEBUG - 2023-10-17 19:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:08:59 --> Total execution time: 0.0551
DEBUG - 2023-10-17 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:10:30 --> No URI present. Default controller set.
DEBUG - 2023-10-17 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:10:30 --> Total execution time: 0.0457
DEBUG - 2023-10-17 19:10:31 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:10:31 --> No URI present. Default controller set.
DEBUG - 2023-10-17 19:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:10:31 --> Total execution time: 0.0461
DEBUG - 2023-10-17 19:12:21 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:21 --> No URI present. Default controller set.
DEBUG - 2023-10-17 19:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:12:21 --> Total execution time: 0.1073
DEBUG - 2023-10-17 19:12:24 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:24 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:56 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:56 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:57 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:57 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:57 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:57 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:58 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:58 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:58 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:58 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:12:58 --> 404 Page Not Found: Gallery/index
DEBUG - 2023-10-17 19:13:41 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:13:41 --> Total execution time: 0.0421
DEBUG - 2023-10-17 19:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:13:48 --> Total execution time: 0.0484
DEBUG - 2023-10-17 19:13:51 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:13:51 --> Total execution time: 0.0435
DEBUG - 2023-10-17 19:15:47 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:15:47 --> Total execution time: 0.0802
DEBUG - 2023-10-17 19:18:10 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-10-17 19:18:10 --> 404 Page Not Found: Contact/index
DEBUG - 2023-10-17 19:18:13 --> UTF-8 Support Enabled
DEBUG - 2023-10-17 19:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-10-17 19:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-10-17 19:18:13 --> Total execution time: 0.0473
